<?php
/**
 * маршрутизатор
 */
class Route
{
    static function start()
    {
        $controller_name = 'Main';
        $action_name = 'index';
        $routes = explode('/', $_SERVER['REQUEST_URI']);
        if(!empty($routes[1])){
            $controller_name = $routes[1];
        }
        if(!empty($routes[2])){
            $action_name = $routes[2];
        }
        $model_name = $controller_name;
        $controller_name = 'Controller_' . $controller_name;
        $model_name = 'Model_' . $model_name;
        $action_name = 'action_' . $action_name;
        $model_path = 'application/models/' . strtolower($model_name) . '.php';
        if(file_exists($model_path)){
            include $model_path;
        }/*else{
            include 'application/models/model_main.php';
        }*/
        $controller_path = 'application/controllers/'
                         . strtolower($controller_name) 
                         . '.php';
        if(file_exists($controller_path)){
            include $controller_path;
        }
        else
        {
            Route::ErrorPage();
        }
        $controller = new $controller_name;
        $action = $action_name;
        if(method_exists($controller, $action)){
            $controller->$action();
        }
        else
        {
            Route::ErrorPage();
        }
    }
    function ErrorPage(){
        $host = 'http://' . $_SERVER['HTTP_HOST'] . '/';
                header('HTTP/1.1 404 Not Found');
                header('Status: 404 Not Found');
                header('Location:' . $host . '404');
    }
}

