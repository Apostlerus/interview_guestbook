<?php
class Model
{
    public function getData(){
        
    }
    public function setData(){
        
    }
}
?>
