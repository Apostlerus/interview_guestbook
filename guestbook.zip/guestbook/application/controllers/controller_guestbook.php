<?php
class Controller_Guestbook extends Controller
{

	function action_index()
	{
            $this->view->generate('main_view.php', 'template_view.php');
	}
        function action_add()
        {
            if(!$_POST){
            $this->view->generate('guestbook_add_view.php', 'template_view.php');
            }else
            {
                require 'application/models/model_main.php'; 
               $this->model = new Model_Main();
               $this->model->set_data($_POST);
               $this->view->generate('guestbook_add_view.php', 'template_view.php');
               
            }
            
            }
}

