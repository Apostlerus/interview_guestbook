<table>
<?php
    foreach($data as $f)
    {
     /*   echo '<tr><td>'.$row['uname'].'</td><td>'.$row['email'].'</td><td>'.$row['msg'].'</td></tr>';
    }*/
$div='';
$div.="<div style='padding:10px';></div><div style='display:inline; text-align:right; '><b>$f[uname]</b>";
$data=$f[date];
//$data=date_ru('�, d � Y',strtotime($data));
echo "$div ($f[email]) ������������: $data</div>";
echo "<div class=\"notification\">";
echo "$f[msg]";
echo "</div>";
    }
    
    
?>
</table>

