<?php
class Model_Main extends Model
/*{
    protected $user;
    protected $email;
    protected $date;
    protected $message;
    function getData(){
        
    }
function setData(){
    
}
}*/
{
    public function get_data()
    {	
        database::Connect('localhost', 'root', '', 'guest_book');
        $query = mysql_query("Select * from messages");
        $arr = array();
        while($f=mysql_fetch_array($query)){ 
            $arr[] = $f;
        }
        return $arr;
    }
    
    public function set_data($params)
    {
            $user = strip_tags(trim($_POST['user']));
            $email = strip_tags(trim($_POST['email']));
            $msg = strip_tags(trim($_POST['message']));
            $date = date("Y-m-d H:i:s");
            database::Connect('localhost', 'root', '', 'guest_book');
            $query = mysql_query("INSERT INTO messages(uname,email,msg,date) VALUES('$user','$email','$msg','$date')");
    }
        
}
